#!/bin/bash

openssl des3 -salt -d -in $2 -k $1

