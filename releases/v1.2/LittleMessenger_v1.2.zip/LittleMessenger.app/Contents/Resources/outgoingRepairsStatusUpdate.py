import gdata.docs
import gdata.docs.service
import gdata.spreadsheet.service
import re, os
import sys

username = sys.argv[1]
passwd = sys.argv[2]
doc_name = sys.argv[3]
spreadsheet_key = sys.argv[4]
row_num = sys.argv[5]
new_status = sys.argv[6]
column_num = sys.argv[7]

# Connect to Google
gd_client = gdata.spreadsheet.service.SpreadsheetsService()
gd_client.email = username
gd_client.password = passwd
gd_client.source = 'LittleMessenger'
gd_client.ProgrammaticLogin()

q = gdata.spreadsheet.service.DocumentQuery()
q['title'] = doc_name
q['title-exact'] = 'true'
feed = gd_client.GetSpreadsheetsFeed(query=q)
spreadsheet_id = feed.entry[0].id.text.rsplit('/',1)[1]
feed = gd_client.GetWorksheetsFeed(spreadsheet_id)
worksheet_id = feed.entry[0].id.text.rsplit('/',1)[1]

rows = gd_client.GetListFeed(spreadsheet_id, worksheet_id).entry

client = gdata.spreadsheet.service.SpreadsheetsService()

gd_client.UpdateCell(row_num, column_num, new_status, spreadsheet_key, worksheet_id)
#change column num from 15 to match doc after test phase